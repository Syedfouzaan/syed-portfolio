globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/C5cKxHpcaEESYfGLlgEtb/_buildManifest.js",
    "static/C5cKxHpcaEESYfGLlgEtb/_ssgManifest.js",
    "static/C5cKxHpcaEESYfGLlgEtb/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0fpki3y6aj230.js",
    "static/chunks/140ovxvjat1ch.js",
    "static/chunks/07lhk_q6pmm3r.js",
    "static/chunks/turbopack-08fpdsd.-ns2y.js"
  ]
};
